export default function Page() {
  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <p className="text-ink-soft text-sm">Trust score — coming in a later step.</p>
    </main>
  );
}
